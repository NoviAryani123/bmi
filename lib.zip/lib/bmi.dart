import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'identitas.dart';
import 'bmi_result.dart';

class InputBMI extends StatefulWidget {
  @override
  _InputBMIState createState() => _InputBMIState();
}

class _InputBMIState extends State<InputBMI> {
  int tinggi = 0;
  int berat = 0;

  

  var _nama = new TextEditingController();
  var _jk = new TextEditingController();
  var _tl = new TextEditingController();
  @override
  Widget build(BuildContext context) {
    return
        Scaffold(
            //backgroundColor: Colors.blue[100],
            appBar: AppBar(
              //backgroundColor: Colors.blue[100],
              centerTitle: true,
              leading: Icon(
                Icons.favorite,
                color: Colors.green,
              ),
              title: Text('HITUNG BMI',style: TextStyle(color: Colors.blue, fontSize: 15),),
             
              backgroundColor: Colors.black12,
                
            ),
            body: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  Container(
                    child:
                    Image.asset('images/cat.jpg',
                      fit: BoxFit.fitWidth,
                      
                    ),
                  ),
                  Container(
                      
                     // color: Colors.blue[700],
                     
                      child: Row(
                        children: <Widget>[
                         
                          Expanded(
                            child: TextField(
                              controller: _nama,
                              keyboardType: TextInputType.text,
                              maxLength: 300,
                              textAlign: TextAlign.left,
                              style: TextStyle(
                                fontSize: 15,
                                
                              ),
                              decoration: InputDecoration(
                                  
                                  fillColor: Colors.blue[900],
                                  filled: true,
                                  hintText: 'Nama'),
                            ),
                          ),
                          
                          SizedBox(
                            width: 5,
                           
                          ),
                          
                          Expanded(
                            child: TextField(
                              
                          controller: _jk,
                              keyboardType: TextInputType.text,
                              maxLength: 300,
                              textAlign: TextAlign.left,
                              style: TextStyle(
                                fontSize: 15,
                              ),
                              decoration: InputDecoration(
                                 
                                fillColor: Colors.blue[900],
                                  filled: true,
                                  hintText: 'Jenis Kelamin'),
                            ),
                          ),
                          
                        ],
                      )),


                    Container(
                      
                     // color: Colors.blue[700],
                      child: Row(
                        children: <Widget>[
                         
                          Expanded(
                            child: TextField(
                              controller: _tl,
                              keyboardType: TextInputType.text,
                              maxLength: 300,
                              textAlign: TextAlign.left,
                              style: TextStyle(
                                fontSize: 15,
                              ),
                              decoration: InputDecoration(
                             
                               border: OutlineInputBorder(
                                     borderRadius: new BorderRadius.circular(10.0)
                                  ),
                                fillColor: Colors.blue[900],
                                  filled: true,
                                  hintText: 'Tanggal Lahir'),
                            ),
                          ),
                          
                          
                          
                        ],
                      )),
                  Container(
                       
                     //color: Colors.blue[700],
                      child: Row(
                        children: <Widget>[
                        
                          Expanded(
                            
                            child: TextField(
                              
                              onChanged: (txt) {
                                setState(() {
                                  tinggi = int.parse(txt);
                                });
                                
                              },
                               
                              keyboardType: TextInputType.number,
                              maxLength: 3,
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: 15,
                              ),
                              decoration: InputDecoration(
                                  suffix: Text('cm'),
                                  fillColor: Colors.blue[900],
                                  filled: true,
                                  hintText: 'Tinggi'),
                            ),
                          ),
                           
                          SizedBox(
                            width: 5,
                           
                          ),

                          Expanded(
                            child: TextField(
                              onChanged: (txt) {
                                setState(() {
                                  berat = int.parse(txt);
                                });
                              },
                              keyboardType: TextInputType.number,
                              maxLength: 3,
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: 15,
                              ),
                              decoration: InputDecoration(
                                  suffix: Text('kg'),
                                  fillColor: Colors.blue[900],
                                  filled: true,
                                  hintText: 'Berat'),
                            ),
                          ),
                        ],
                      )),


                    


                  Container(
                   //height: double.infinity,
                     margin: EdgeInsets.only(left: 10,right: 10),
                     child: RaisedButton(
                       onPressed: () {
                         Navigator.of(context).push(
                           
                           MaterialPageRoute(builder: (context) => BMIResult(tinggi_badan: tinggi, berat_badan: berat, nama_pengguna:_nama.text, jenis_kelammin:_jk.text, tanggal_lahir:_tl.text)),
                         );
                       },
                       
                       color: Colors.blue[900],
                        textColor: Colors.red,
                       child: Text(
                         'HITUNG BMI',
                         style:
                         TextStyle(fontSize: 15, fontWeight: FontWeight.w500),
                       ),
                     ),
                   ),


                  Container(
                   //height: double.infinity,
                     margin: EdgeInsets.only(left: 10,right: 10),
                     child: RaisedButton(
                       onPressed: () {
                         Navigator.of(context).push(
                           
                           MaterialPageRoute(builder: (context) => HalamanSatu()),
                         );
                       },
                       
                       color: Colors.blue[900],
                        textColor: Colors.red,
                       child: Text(
                         'Tentang',
                         style:
                         TextStyle(fontSize: 15, fontWeight: FontWeight.w500),
                       ),
                     ),
                   ),
                  


                ],
              ),
            ),
          bottomNavigationBar: BottomAppBar(
            //color: Colors.transparen,
            child: Container(
              height: 30,
              color: Colors.red[900],
              alignment: Alignment.center,
              child: Text(
                'Developed by Ida Ayu Windy Prabawanti',
                style: TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.w500,
                    color: Colors.blue),
              ),
            ),
            //elevation: 0,
          ),
        );
  }
}