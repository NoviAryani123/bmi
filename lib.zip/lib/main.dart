import 'package:flutter/material.dart';
import 'bmi.dart';

void main() => runApp(
  MaterialApp(
    theme: ThemeData.dark(),
    home:  InputBMI(),
  )

);